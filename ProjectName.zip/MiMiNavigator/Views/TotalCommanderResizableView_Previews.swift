//
//  TotalCommanderResizableView_Previews.swift
//  MiMiNavigator
//
//  Created by Iakov Senatov on 16.10.24.

//  Description:
//

import SwiftUI

struct TotalCommanderResizableView_Previews: PreviewProvider {
    static var previews: some View {
        TotalCommanderResizableView()
    }
}