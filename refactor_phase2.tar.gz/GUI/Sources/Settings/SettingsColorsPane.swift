// SettingsColorsPane.swift
// MiMiNavigator
//
// Created by Iakov Senatov on 24.02.2026.
// Copyright © 2026 Senatov. All rights reserved.
// Description: Colors settings — named color tokens, Light/Dark variants, preset themes.
//   All colors pulled from FilePanelStyle, DesignTokens, DialogColors.
//   Stored in AppStorage as hex strings, applied via ColorThemeStore.

import AppKit
import SwiftUI

// MARK: - Color Theme Model

struct ColorTheme: Identifiable, Equatable {
    let id: String
    let name: String

    // Panel
    var panelBackground: Color
    var panelText: Color
    var dirNameColor: Color
    var fileNameColor: Color
    var symlinkColor: Color

    // Selection
    var selectionActive: Color
    var selectionInactive: Color
    var selectionBorder: Color
    var selectionLineWidth: CGFloat

    // UI chrome
    var separatorColor: Color
    var dialogBase: Color
    var dialogStripe: Color
    var accentColor: Color
    /// Background of floating dialog windows (Find Files, Settings, etc.)
    /// Matches active panel background, slightly more transparent.
    var dialogBackground: Color

    // Special file states
    var hiddenFileColor: Color
    var markedFileColor: Color
    var parentEntryColor: Color
    var archivePathColor: Color
    var markedCountColor: Color

    // Column accent colors
    var columnNameColor: Color
    var columnSizeColor: Color
    var columnKindColor: Color
    var columnDateColor: Color

    var columnPermissionsColor: Color
    var columnOwnerColor: Color
    var columnGroupColor: Color
    var columnChildCountColor: Color
    // Panel divider
    var dividerNormalColor: Color
    var dividerActiveColor: Color

    // Panel border
    var panelBorderActive: Color
    var panelBorderInactive: Color

    // Zebra stripe base for active panel
    var warmWhite: Color

    // Filter bar active highlight
    var filterActiveColor: Color

    // Dark variants (nil = same as light)
    var panelBackgroundDark: Color?
    var panelTextDark: Color?
    var dirNameColorDark: Color?
    var selectionActiveDark: Color?
}

// MARK: - Built-in Presets

extension ColorTheme {

    /// Default — matches current hardcoded values exactly
    static let defaultTheme = ColorTheme(
        id: "default",
        name: "Default",
        panelBackground:    Color(nsColor: .controlBackgroundColor),
        panelText:          Color.primary,
        dirNameColor:       Color.primary,
        fileNameColor:      Color.primary,
        symlinkColor:       Color(nsColor: .linkColor),
        selectionActive:    Color(red: 255/255, green: 255/255, blue: 220/255),
        selectionInactive:  Color(nsColor: .unemphasizedSelectedContentBackgroundColor),
        selectionBorder:    Color(red: 0/255, green: 100/255, blue: 225/255),
        selectionLineWidth: 2.0,
        separatorColor:     Color(nsColor: .separatorColor),
        dialogBase:         Color(red: 239/255, green: 239/255, blue: 239/255),
        dialogStripe:       Color(red: 231/255, green: 231/255, blue: 231/255),
        accentColor:        Color.accentColor,
        dialogBackground:   Color(red: 239/255, green: 239/255, blue: 239/255),
        hiddenFileColor:     Color(red: 0.38, green: 0.38, blue: 0.38),
        markedFileColor:     Color(red: 0.45, green: 0.0, blue: 0.0),
        parentEntryColor:    Color(red: 0.2, green: 0.2, blue: 0.7),
        archivePathColor:    Color(red: 0.1, green: 0.1, blue: 0.55),
        markedCountColor:    Color(red: 0.7, green: 0.0, blue: 0.0),
        columnNameColor:     Color(red: 0.05, green: 0.10, blue: 0.30),
        columnSizeColor:     Color(red: 0.50, green: 0.05, blue: 0.18),
        columnKindColor:     Color(red: 0.28, green: 0.14, blue: 0.05),
        columnDateColor:     Color(red: 0.05, green: 0.28, blue: 0.10),
        columnPermissionsColor: Color(red: 0.22, green: 0.22, blue: 0.40),
        columnOwnerColor:       Color(red: 0.20, green: 0.30, blue: 0.20),
        columnGroupColor:       Color(red: 0.28, green: 0.20, blue: 0.30),
        columnChildCountColor:  Color(red: 0.30, green: 0.20, blue: 0.10),
        dividerNormalColor:  Color(red: 0.42, green: 0.42, blue: 0.46, opacity: 0.55),
        dividerActiveColor:  Color(red: 0.22, green: 0.01, blue: 0.85, opacity: 0.90),
        panelBorderActive:   Color(red: 0.50, green: 0.50, blue: 0.55, opacity: 0.55),
        panelBorderInactive: Color(red: 0.45, green: 0.45, blue: 0.50, opacity: 0.38),
        warmWhite:           Color(red: 0.97, green: 0.97, blue: 0.95, opacity: 0.91),
        filterActiveColor:   Color(red: 0.25, green: 0.55, blue: 1.0, opacity: 0.8),
        panelBackgroundDark: Color(nsColor: .windowBackgroundColor),
        panelTextDark:       Color.primary,
        dirNameColorDark:    Color.primary,
        selectionActiveDark: Color(nsColor: .selectedContentBackgroundColor)
    )

    /// Warm — amber/cream tones like ForkLift's warm mode
    static let warmTheme = ColorTheme(
        id: "warm",
        name: "Warm",
        panelBackground:    Color(red: 252/255, green: 248/255, blue: 240/255),
        panelText:          Color(red: 40/255,  green: 35/255,  blue: 28/255),
        dirNameColor:       Color(red: 80/255,  green: 60/255,  blue: 20/255),
        fileNameColor:      Color(red: 40/255,  green: 35/255,  blue: 28/255),
        symlinkColor:       Color(red: 180/255, green: 100/255, blue: 20/255),
        selectionActive:    Color(red: 255/255, green: 200/255, blue: 100/255),
        selectionInactive:  Color(red: 250/255, green: 235/255, blue: 200/255),
        selectionBorder:    Color(red: 210/255, green: 150/255, blue: 60/255).opacity(0.5),
        selectionLineWidth: 2.0,
        separatorColor:     Color(red: 200/255, green: 185/255, blue: 160/255),
        dialogBase:         Color(red: 250/255, green: 245/255, blue: 235/255),
        dialogStripe:       Color(red: 245/255, green: 238/255, blue: 224/255),
        accentColor:        Color(red: 210/255, green: 140/255, blue: 40/255),
        dialogBackground:   Color(red: 252/255, green: 248/255, blue: 240/255).opacity(0.92),
        hiddenFileColor:     Color(red: 0.55, green: 0.48, blue: 0.38),
        markedFileColor:     Color(red: 0.60, green: 0.15, blue: 0.0),
        parentEntryColor:    Color(red: 0.50, green: 0.35, blue: 0.10),
        archivePathColor:    Color(red: 0.40, green: 0.25, blue: 0.05),
        markedCountColor:    Color(red: 0.70, green: 0.20, blue: 0.0),
        columnNameColor:     Color(red: 0.35, green: 0.25, blue: 0.10),
        columnSizeColor:     Color(red: 0.55, green: 0.25, blue: 0.10),
        columnKindColor:     Color(red: 0.40, green: 0.28, blue: 0.12),
        columnDateColor:     Color(red: 0.30, green: 0.38, blue: 0.12),
        columnPermissionsColor: Color(red: 0.48, green: 0.38, blue: 0.20),
        columnOwnerColor:       Color(red: 0.40, green: 0.42, blue: 0.20),
        columnGroupColor:       Color(red: 0.45, green: 0.30, blue: 0.25),
        columnChildCountColor:  Color(red: 0.50, green: 0.30, blue: 0.15),
        dividerNormalColor:  Color(red: 0.60, green: 0.55, blue: 0.45, opacity: 0.55),
        dividerActiveColor:  Color(red: 0.82, green: 0.55, blue: 0.15, opacity: 0.90),
        panelBorderActive:   Color(red: 0.70, green: 0.55, blue: 0.30, opacity: 0.55),
        panelBorderInactive: Color(red: 0.60, green: 0.55, blue: 0.45, opacity: 0.38),
        warmWhite:           Color(red: 0.99, green: 0.97, blue: 0.92, opacity: 0.91),
        filterActiveColor:   Color(red: 0.75, green: 0.50, blue: 0.10, opacity: 0.8),
        panelBackgroundDark: Color(red: 40/255, green: 35/255, blue: 28/255),
        panelTextDark:       Color(red: 240/255, green: 225/255, blue: 200/255),
        dirNameColorDark:    Color(red: 255/255, green: 200/255, blue: 120/255),
        selectionActiveDark: Color(red: 100/255, green: 75/255, blue: 30/255)
    )

    /// Midnight — dark blue like Nova / Sublime Text
    static let midnightTheme = ColorTheme(
        id: "midnight",
        name: "Midnight",
        panelBackground:    Color(red: 30/255,  green: 35/255,  blue: 50/255),
        panelText:          Color(red: 210/255, green: 215/255, blue: 230/255),
        dirNameColor:       Color(red: 130/255, green: 180/255, blue: 255/255),
        fileNameColor:      Color(red: 210/255, green: 215/255, blue: 230/255),
        symlinkColor:       Color(red: 100/255, green: 220/255, blue: 200/255),
        selectionActive:    Color(red: 50/255,  green: 80/255,  blue: 130/255),
        selectionInactive:  Color(red: 40/255,  green: 50/255,  blue: 75/255),
        selectionBorder:    Color(red: 80/255,  green: 130/255, blue: 220/255).opacity(0.6),
        selectionLineWidth: 2.0,
        separatorColor:     Color(red: 55/255,  green: 65/255,  blue: 90/255),
        dialogBase:         Color(red: 35/255,  green: 40/255,  blue: 58/255),
        dialogStripe:       Color(red: 28/255,  green: 33/255,  blue: 50/255),
        accentColor:        Color(red: 80/255,  green: 150/255, blue: 255/255),
        dialogBackground:   Color(red: 30/255,  green: 35/255,  blue: 50/255).opacity(0.92),
        hiddenFileColor:     Color(red: 0.45, green: 0.48, blue: 0.55),
        markedFileColor:     Color(red: 1.0, green: 0.45, blue: 0.35),
        parentEntryColor:    Color(red: 0.55, green: 0.70, blue: 1.0),
        archivePathColor:    Color(red: 0.50, green: 0.65, blue: 1.0),
        markedCountColor:    Color(red: 1.0, green: 0.40, blue: 0.35),
        columnNameColor:     Color(red: 0.50, green: 0.65, blue: 0.90),
        columnSizeColor:     Color(red: 0.85, green: 0.50, blue: 0.60),
        columnKindColor:     Color(red: 0.70, green: 0.60, blue: 0.50),
        columnDateColor:     Color(red: 0.45, green: 0.75, blue: 0.55),
        columnPermissionsColor: Color(red: 0.65, green: 0.60, blue: 0.85),
        columnOwnerColor:       Color(red: 0.50, green: 0.80, blue: 0.65),
        columnGroupColor:       Color(red: 0.70, green: 0.55, blue: 0.80),
        columnChildCountColor:  Color(red: 0.75, green: 0.70, blue: 0.50),
        dividerNormalColor:  Color(red: 0.35, green: 0.40, blue: 0.55, opacity: 0.60),
        dividerActiveColor:  Color(red: 0.40, green: 0.60, blue: 1.0, opacity: 0.90),
        panelBorderActive:   Color(red: 0.35, green: 0.50, blue: 0.80, opacity: 0.60),
        panelBorderInactive: Color(red: 0.30, green: 0.35, blue: 0.50, opacity: 0.40),
        warmWhite:           Color(red: 0.16, green: 0.18, blue: 0.26, opacity: 0.50),
        filterActiveColor:   Color(red: 0.40, green: 0.65, blue: 1.0, opacity: 0.8),
        panelBackgroundDark: nil,
        panelTextDark:       nil,
        dirNameColorDark:    nil,
        selectionActiveDark: nil
    )

    /// Solarized — classic terminal palette
    static let solarizedTheme = ColorTheme(
        id: "solarized",
        name: "Solarized",
        panelBackground:    Color(red: 253/255, green: 246/255, blue: 227/255),
        panelText:          Color(red: 101/255, green: 123/255, blue: 131/255),
        dirNameColor:       Color(red: 38/255,  green: 139/255, blue: 210/255),
        fileNameColor:      Color(red: 101/255, green: 123/255, blue: 131/255),
        symlinkColor:       Color(red: 42/255,  green: 161/255, blue: 152/255),
        selectionActive:    Color(red: 238/255, green: 232/255, blue: 213/255),
        selectionInactive:  Color(red: 147/255, green: 161/255, blue: 161/255).opacity(0.2),
        selectionBorder:    Color(red: 38/255,  green: 139/255, blue: 210/255).opacity(0.4),
        selectionLineWidth: 2.0,
        separatorColor:     Color(red: 147/255, green: 161/255, blue: 161/255).opacity(0.5),
        dialogBase:         Color(red: 250/255, green: 244/255, blue: 222/255),
        dialogStripe:       Color(red: 245/255, green: 238/255, blue: 214/255),
        accentColor:        Color(red: 38/255,  green: 139/255, blue: 210/255),
        dialogBackground:   Color(red: 253/255, green: 246/255, blue: 227/255).opacity(0.92),
        hiddenFileColor:     Color(red: 0.58, green: 0.63, blue: 0.63),
        markedFileColor:     Color(red: 0.86, green: 0.20, blue: 0.18),
        parentEntryColor:    Color(red: 0.15, green: 0.55, blue: 0.82),
        archivePathColor:    Color(red: 0.15, green: 0.55, blue: 0.82),
        markedCountColor:    Color(red: 0.86, green: 0.20, blue: 0.18),
        columnNameColor:     Color(red: 0.15, green: 0.55, blue: 0.82),
        columnSizeColor:     Color(red: 0.52, green: 0.60, blue: 0.0),
        columnKindColor:     Color(red: 0.71, green: 0.54, blue: 0.0),
        columnDateColor:     Color(red: 0.16, green: 0.63, blue: 0.60),
        columnPermissionsColor: Color(red: 0.60, green: 0.20, blue: 0.00),
        columnOwnerColor:       Color(red: 0.52, green: 0.60, blue: 0.00),
        columnGroupColor:       Color(red: 0.71, green: 0.54, blue: 0.00),
        columnChildCountColor:  Color(red: 0.42, green: 0.16, blue: 0.51),
        dividerNormalColor:  Color(red: 0.58, green: 0.63, blue: 0.63, opacity: 0.50),
        dividerActiveColor:  Color(red: 0.15, green: 0.55, blue: 0.82, opacity: 0.90),
        panelBorderActive:   Color(red: 0.15, green: 0.55, blue: 0.82, opacity: 0.50),
        panelBorderInactive: Color(red: 0.58, green: 0.63, blue: 0.63, opacity: 0.35),
        warmWhite:           Color(red: 0.99, green: 0.96, blue: 0.89, opacity: 0.50),
        filterActiveColor:   Color(red: 0.15, green: 0.55, blue: 0.82, opacity: 0.8),
        panelBackgroundDark: Color(red: 0/255,   green: 43/255,  blue: 54/255),
        panelTextDark:       Color(red: 131/255, green: 148/255, blue: 150/255),
        dirNameColorDark:    Color(red: 38/255,  green: 139/255, blue: 210/255),
        selectionActiveDark: Color(red: 7/255,   green: 54/255,  blue: 66/255)
    )

    static let allPresets: [ColorTheme] = [.defaultTheme, .warmTheme, .midnightTheme, .solarizedTheme]
}


// MARK: - SettingsColorsPane

struct SettingsColorsPane: View {

    @State private var store = ColorThemeStore.shared
    @State private var selectedPresetID: String = ColorThemeStore.shared.activeTheme.id
    @State private var useDarkVariant: Bool = ColorThemeStore.shared.useDarkVariant

    // Custom color bindings (shown in color wells)
    @AppStorage("color.panelBackground")   private var hexPanelBg: String = ""
    @AppStorage("color.panelText")         private var hexPanelText: String = ""
    @AppStorage("color.dirName")           private var hexDirName: String = ""
    @AppStorage("color.fileName")          private var hexFileName: String = ""
    @AppStorage("color.symlink")           private var hexSymlink: String = ""
    @AppStorage("color.selectionActive")   private var hexSelActive: String = ""
    @AppStorage("color.selectionInactive") private var hexSelInactive: String = ""
    @AppStorage("color.selectionBorder")   private var hexSelBorder: String = ""
    @AppStorage("selection.lineWidth")     private var selLineWidth: Double = 2.0
    @AppStorage("color.accent")            private var hexAccent: String = ""
    @AppStorage("color.dialogBackground")  private var hexDialogBg: String = ""
    @AppStorage("button.borderColor")        private var hexButtonBorder: String = ""
    @AppStorage("button.shadowColor")        private var hexButtonShadow: String = ""
    // Extended color tokens
    @AppStorage("color.hiddenFile")       private var hexHiddenFile: String = ""
    @AppStorage("color.markedFile")       private var hexMarkedFile: String = ""
    @AppStorage("color.parentEntry")      private var hexParentEntry: String = ""
    @AppStorage("color.archivePath")      private var hexArchivePath: String = ""
    @AppStorage("color.markedCount")      private var hexMarkedCount: String = ""
    @AppStorage("color.columnName")       private var hexColumnName: String = ""
    @AppStorage("color.columnSize")       private var hexColumnSize: String = ""
    @AppStorage("color.columnKind")       private var hexColumnKind: String = ""
    @AppStorage("color.columnDate")       private var hexColumnDate: String = ""
    @AppStorage("color.columnPermissions") private var hexColumnPermissions: String = ""
    @AppStorage("color.columnOwner")       private var hexColumnOwner: String = ""
    @AppStorage("color.columnGroup")       private var hexColumnGroup: String = ""
    @AppStorage("color.columnChildCount")  private var hexColumnChildCount: String = ""
    @AppStorage("color.dividerNormal")    private var hexDividerNormal: String = ""
    @AppStorage("color.dividerActive")    private var hexDividerActive: String = ""
    @AppStorage("color.panelBorderActive")   private var hexPanelBorderActive: String = ""
    @AppStorage("color.panelBorderInactive") private var hexPanelBorderInactive: String = ""
    @AppStorage("color.warmWhite")        private var hexWarmWhite: String = ""
    @AppStorage("color.filterActive")     private var hexFilterActive: String = ""

    private var currentPreset: ColorTheme {
        ColorTheme.allPresets.first { $0.id == selectedPresetID } ?? .defaultTheme
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {

            // ── Theme Preset Picker ──────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    rowLabel("Theme preset:", help: "Choose a built-in color theme as starting point") {
                        HStack(spacing: 8) {
                            Picker("", selection: $selectedPresetID) {
                                ForEach(ColorTheme.allPresets) { theme in
                                    Text(theme.name).tag(theme.id)
                                }
                            }
                            .labelsHidden()
                            .frame(width: 160)
                            .onChange(of: selectedPresetID) { _, id in
                                store.applyPreset(ColorTheme.allPresets.first { $0.id == id } ?? .defaultTheme)
                            }

                            // Live preview swatches
                            HStack(spacing: 4) {
                                swatch(currentPreset.panelBackground, label: "BG")
                                swatch(currentPreset.panelText, label: "Text")
                                swatch(currentPreset.dirNameColor, label: "Dir")
                                swatch(currentPreset.selectionActive, label: "Sel")
                                swatch(currentPreset.accentColor, label: "Acc")
                            }
                        }
                    }

                    Divider()

                    rowLabel("Dark variant:", help: "Use separate dark-mode colors when system is in Dark Mode") {
                        Toggle("Use separate dark-mode colors", isOn: $useDarkVariant)
                            .toggleStyle(.checkbox)
                            .onChange(of: useDarkVariant) { _, v in store.useDarkVariant = v }
                    }
                }
            }

            // ── Color Tokens ─────────────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Panel")
                    colorRow("Panel background",  help: "Background color of file list panels",
                             preset: currentPreset.panelBackground,    hex: $hexPanelBg)
                    Divider()
                    colorRow("File name",         help: "Regular file name text color",
                             preset: currentPreset.fileNameColor,      hex: $hexFileName)
                    Divider()
                    colorRow("Directory name",    help: "Directory name text color",
                             preset: currentPreset.dirNameColor,       hex: $hexDirName)
                    Divider()
                    colorRow("Symlink",           help: "Symbolic link name color",
                             preset: currentPreset.symlinkColor,       hex: $hexSymlink)
                }
            }

            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Selection")
                    colorRow("Active selection",   help: "Selected row when panel is focused",
                             preset: currentPreset.selectionActive,    hex: $hexSelActive)
                    Divider()
                    colorRow("Inactive selection", help: "Selected row when panel is unfocused",
                             preset: currentPreset.selectionInactive,  hex: $hexSelInactive)
                    Divider()
                    colorRow("Selection border",  help: "Top and bottom lines of selected row",
                             preset: currentPreset.selectionBorder,    hex: $hexSelBorder)
                    Divider()
                    HStack {
                        Text("Line width:")
                            .frame(width: 150, alignment: .trailing)
                        Slider(value: $selLineWidth,
                         in: 0.5...4.0, step: 0.5)
                        Text(String(format: "%.1f", selLineWidth))
                            .frame(width: 30)
                    }
                    .padding(.vertical, 4)
                }
            }

            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Accent")
                    colorRow("Accent color", help: "Used for buttons, highlights, active borders",
                             preset: currentPreset.accentColor, hex: $hexAccent)
                }
            }

            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Dialogs")
                    colorRow("Dialog background",
                             help: "Background of Find Files, Settings, and other floating panels. Matches active panel color at 92% opacity.",
                             preset: currentPreset.dialogBackground,
                             hex: $hexDialogBg)
                }
            }


            // ── File States ──────────────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("File States")
                    colorRow("Hidden files", help: "Dimmed text for .dotfiles",
                             preset: currentPreset.hiddenFileColor, hex: $hexHiddenFile)
                    Divider()
                    colorRow("Marked files", help: "TC-style marked file text (Insert key)",
                             preset: currentPreset.markedFileColor, hex: $hexMarkedFile)
                    Divider()
                    colorRow("Parent entry", help: "Color of '..' parent directory row",
                             preset: currentPreset.parentEntryColor, hex: $hexParentEntry)
                    Divider()
                    colorRow("Archive path", help: "Text color for files found inside archives",
                             preset: currentPreset.archivePathColor, hex: $hexArchivePath)
                    Divider()
                    colorRow("Marked count", help: "Status bar marked files counter",
                             preset: currentPreset.markedCountColor, hex: $hexMarkedCount)
                }
            }

            // ── Column Colors ────────────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Column Colors")
                    colorRow("Name column", help: "Text accent for Name column content",
                             preset: currentPreset.columnNameColor, hex: $hexColumnName)
                    Divider()
                    colorRow("Size column", help: "Text accent for Size column content",
                             preset: currentPreset.columnSizeColor, hex: $hexColumnSize)
                    Divider()
                    colorRow("Kind column", help: "Text accent for Kind column content",
                             preset: currentPreset.columnKindColor, hex: $hexColumnKind)
                    Divider()
                    colorRow("Date column", help: "Text accent for all Date columns",
                             preset: currentPreset.columnDateColor, hex: $hexColumnDate)
                    Divider()
                    colorRow("Permissions column", help: "Text accent for Permissions column",
                               preset: currentPreset.columnPermissionsColor, hex: $hexColumnPermissions)
                    Divider()
                    colorRow("Owner column", help: "Text accent for Owner column",
                               preset: currentPreset.columnOwnerColor, hex: $hexColumnOwner)
                    Divider()
                    colorRow("Group column", help: "Text accent for Group column",
                               preset: currentPreset.columnGroupColor, hex: $hexColumnGroup)
                    Divider()
                    colorRow("# Count column", help: "Text accent for child count column",
                               preset: currentPreset.columnChildCountColor, hex: $hexColumnChildCount)
                }
            }

            // ── UI Chrome ────────────────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("UI Chrome")
                    colorRow("Divider normal", help: "Panel divider color in passive state",
                             preset: currentPreset.dividerNormalColor, hex: $hexDividerNormal)
                    Divider()
                    colorRow("Divider active", help: "Panel divider color while dragging",
                             preset: currentPreset.dividerActiveColor, hex: $hexDividerActive)
                    Divider()
                    colorRow("Panel border (active)", help: "Focused panel border color",
                             preset: currentPreset.panelBorderActive, hex: $hexPanelBorderActive)
                    Divider()
                    colorRow("Panel border (inactive)", help: "Unfocused panel border color",
                             preset: currentPreset.panelBorderInactive, hex: $hexPanelBorderInactive)
                    Divider()
                    colorRow("Warm white", help: "Active panel zebra stripe background",
                             preset: currentPreset.warmWhite, hex: $hexWarmWhite)
                    Divider()
                    colorRow("Filter highlight", help: "Filter bar border when focused",
                             preset: currentPreset.filterActiveColor, hex: $hexFilterActive)
                }
            }

            // ── Buttons ───────────────────────────────────────────
            settingsGroupBox {
                VStack(spacing: 0) {
                    sectionHeader("Buttons")
                    colorRow("Border color", help: "Border color for themed buttons",
                             preset: Color.gray.opacity(0.35), hex: $hexButtonBorder)
                    Divider()
                    rowLabel("Border width:", help: "Thickness of button border line") {
                        HStack(spacing: 10) {
                            Slider(value: $store.buttonBorderWidth, in: 0...3, step: 0.25)
                                .frame(width: 120)
                            Text(String(format: "%.2f", store.buttonBorderWidth))
                                .monospacedDigit().foregroundStyle(.secondary).frame(width: 36)
                        }
                    }
                    Divider()
                    rowLabel("Corner radius:", help: "Roundness of button corners") {
                        HStack(spacing: 10) {
                            Slider(value: $store.buttonCornerRadius, in: 0...16, step: 1)
                                .frame(width: 120)
                            Text("\(Int(store.buttonCornerRadius)) pt")
                                .monospacedDigit().foregroundStyle(.secondary).frame(width: 36)
                        }
                    }
                    Divider()
                    colorRow("Shadow color", help: "Shadow color under buttons",
                             preset: Color.black.opacity(0.1), hex: $hexButtonShadow)
                    Divider()
                    rowLabel("Shadow radius:", help: "Blur radius of button shadow") {
                        HStack(spacing: 10) {
                            Slider(value: $store.buttonShadowRadius, in: 0...8, step: 0.5)
                                .frame(width: 120)
                            Text(String(format: "%.1f", store.buttonShadowRadius))
                                .monospacedDigit().foregroundStyle(.secondary).frame(width: 36)
                        }
                    }
                    Divider()
                    // Live preview
                    rowLabel("Preview:", help: "How themed buttons look with current settings") {
                        HStack(spacing: 12) {
                            Button("Settings") {}
                                .buttonStyle(ThemedButtonStyle())
                            Button("Reset to Default") {}
                                .buttonStyle(ThemedButtonStyle())
                        }
                    }
                }
            }

            // ── Reset ─────────────────────────────────────────
            HStack {
                Spacer()
                Button("Reset to Default") {
                    selectedPresetID = "default"
                    store.applyPreset(.defaultTheme)
                    // Reset button params too
                    store.hexButtonBorder = ""
                    store.buttonBorderWidth = 0.5
                    store.buttonCornerRadius = 6.0
                    store.hexButtonShadow = ""
                    store.buttonShadowRadius = 1.0
                    store.buttonShadowY = 0.5
                }
                .buttonStyle(ThemedButtonStyle())
                .tint(.red)
            }
        }
    }

    // MARK: - Helpers

    private func swatch(_ color: Color, label: String) -> some View {
        VStack(spacing: 2) {
            RoundedRectangle(cornerRadius: 3)
                .fill(color)
                .frame(width: 18, height: 14)
                .overlay(RoundedRectangle(cornerRadius: 3).stroke(Color.black.opacity(0.1), lineWidth: 0.5))
            Text(label)
                .font(.system(size: 8))
                .foregroundStyle(.secondary)
        }
    }

    private func sectionHeader(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(.secondary)
            .textCase(.uppercase)
            .padding(.horizontal, 0)
            .padding(.top, 4)
            .padding(.bottom, 6)
    }

    /// One color token row: label + preset swatch + override ColorPicker + reset button
    private func colorRow(_ label: String, help: String, preset: Color, hex: Binding<String>) -> some View {
        rowLabel(label + ":", help: help) {
            HStack(spacing: 10) {
                // Preset default swatch (read-only reference)
                RoundedRectangle(cornerRadius: 3)
                    .fill(preset)
                    .frame(width: 22, height: 16)
                    .overlay(RoundedRectangle(cornerRadius: 3).stroke(Color.black.opacity(0.12), lineWidth: 0.5))
                    .help("Preset default")

                Text("→")
                    .foregroundStyle(.tertiary)
                    .font(.system(size: 11))

                // Custom override ColorPicker
                ColorPicker("", selection: colorBinding(hex: hex, fallback: preset))
                    .labelsHidden()
                    .frame(width: 28)

                // Reset individual token
                if !hex.wrappedValue.isEmpty {
                    Button {
                        hex.wrappedValue = ""
                        store.reloadOverrides()
                    } label: {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 10))
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.secondary)
                    .help("Reset to preset default")
                }
            }
        }
    }

    private func rowLabel<C: View>(_ label: String, help: String, @ViewBuilder content: () -> C) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 0) {
            Text(label)
                .font(.system(size: 13))
                .foregroundStyle(.secondary)
                .frame(width: 180, alignment: .trailing)
                .help(help)
            Spacer().frame(width: 16)
            content()
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 6)
    }

    private func settingsGroupBox<C: View>(@ViewBuilder content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 0) { content() }
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(DialogColors.light))
            .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(DialogColors.border.opacity(0.5), lineWidth: 0.5))
    }

    /// Binding<Color> from hex AppStorage, falls back to preset color
    private func colorBinding(hex: Binding<String>, fallback: Color) -> Binding<Color> {
        Binding<Color>(
            get: {
                hex.wrappedValue.isEmpty ? fallback : Color(hex: hex.wrappedValue) ?? fallback
            },
            set: { newColor in
                hex.wrappedValue = newColor.toHex() ?? ""
                store.reloadOverrides()
            }
        )
    }
}

// MARK: - Color hex helpers

extension Color {
    init?(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        guard h.count == 6, let val = UInt64(h, radix: 16) else { return nil }
        self.init(
            red:   Double((val >> 16) & 0xFF) / 255,
            green: Double((val >>  8) & 0xFF) / 255,
            blue:  Double((val >>  0) & 0xFF) / 255
        )
    }

    func toHex() -> String? {
        guard let components = NSColor(self).usingColorSpace(.sRGB)?.cgColor.components,
              components.count >= 3 else { return nil }
        let r = Int(components[0] * 255)
        let g = Int(components[1] * 255)
        let b = Int(components[2] * 255)
        return String(format: "%02X%02X%02X", r, g, b)
    }

    /// Blend with another color by fraction (0.0 = self, 1.0 = other)
    func blended(with other: Color, fraction: Double) -> Color {
        guard let c1 = NSColor(self).usingColorSpace(.sRGB)?.cgColor.components,
              let c2 = NSColor(other).usingColorSpace(.sRGB)?.cgColor.components,
              c1.count >= 3, c2.count >= 3 else { return self }
        let f = max(0, min(1, fraction))
        return Color(
            red:   c1[0] * (1 - f) + c2[0] * f,
            green: c1[1] * (1 - f) + c2[1] * f,
            blue:  c1[2] * (1 - f) + c2[2] * f
        )
    }
}
